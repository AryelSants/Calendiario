import * as eventsRepository from "./events.repository";
export async function listAll() {
return eventsRepository.findAll();
}